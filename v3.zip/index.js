const scriptName = "[ 링크 감지 코드 ]";

let url_detect = require("url-detect").main;
let { detectURL } = require("detectURL");

function response(room, msg, sender, isGroupChat, replier, imageDB, packageName) {
  if(msg == "!개발자") {
    replier.reply(room+"에서 "+msg+" 명령어 호출!"+"\u200b".repeat(500)+"\n호출한 이: "+sender+"\n단톡방: "+isGroupChat+"\n프로필 사진: "+imageDB+"\n앱: "+packageName+"\n\n개발자: Semi , DB_Loader , 노는앱");
  }
  try{
  let detects = url_detect(msg);
  if(10 < detects.toString().length) replier.reply("[ 링크 감지 v3.1 ]"+"\u200b".repeat(500)+"\n\n"+detects);
  }catch(e) {
    let d = detectURL(msg);
    if(2 < d.toString().length) replier.reply('[ 링크 감지 v3.1 ]'+"\u200b".repeat(500)+"\n\n"+d);
  }
}
