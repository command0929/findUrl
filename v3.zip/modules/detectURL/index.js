
    'use strict';
    const { Jsoup, Connection } = org.jsoup;
    const { UnknownHostException, MalformedURLException } = java.net;
    const { findURL } = require('./util');

    /**
     * find all urls in text and validate them
     * @param {string} text
     * @returns {string[]} urls that are valid
     */
    exports.detectURL = function(text) {
        const urls = findURL(text);
        
        if (urls.length === 0) return null;

        return urls.map(url => {
            
            if (!url.startsWith('http')) url = 'http://' + url;
            
            try {
                const response = Jsoup.connect(url)
                    .timeout(2300)
                    .ignoreContentType(true)
                    .ignoreHttpErrors(true)
                    .get();
                return "url : "+url.replace("http://","")+"\n\n"+"사이트 : "+response.select("title").text()
            } catch (e) {
            Log.d(e);
                if (e instanceof UnknownHostException) {
                    // 알 수 없는 호스트
                } else if (e instanceof MalformedURLException) {
                    // 잘못된 URL
                } else {
                    // 기타 등등
                }
            }
        }).join("\n\n\n");
    }
