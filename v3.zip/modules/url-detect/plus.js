// 메인 코드 보조

/* convertString(st: String): {
  has?: Number,
  html?: Array,
  url?: Array
}

has: url 수
html: 사이트 HTML 배열
url: url 링크 배열
*/
/**
 * has: url 수
 * html: 사이트 HTML 배열
 * url: url 링크 배열
 * @param {string} st
 * @returns {{has?: number, html?: unknown[], url?: unknown[]}}
 */
function convertString(st) {
  let result = {
    has: 0,
    html: [],
    url: []
  };

  const connect = org.jsoup.Jsoup.connect;
  const ip_reg = new RegExp("((25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[0-9]))", "g");
  
  const url_reg = new RegExp("[-a-zA-Z\uac00-\ud7a30-9:.\\]{2,256}\\.[a-z\uac00-\ud7a30-9]{2,6}\\b([-a-zA-Z\u3131-\u314e\u314f-\u3163\uac00-\ud7a30-9@:%_\\+.~#?&//=]*)", "g");
  //172.217.25.174  <- google   같은 건 어떻게 검출하실  건건ㄱ가가오  오오  <- 아주 잘 누가 정규식으로 해줬음
  let data;  // How to USE   같이 써야죠 ㅇㅅㅇ   ㅁㄴㅇㄹ
  const userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0";
  let url = st.match(url_reg).map(e => "https://" + e)
  /*
   VPN 사용 권장 소스
   우리한테는 Alt + Shift + F라는 아주 좋은 (코드) 포매터가 있슴다 (컴퓨터 포맷시킬 때 그 포맷 아님미다!!!!)
  */
  url.forEach(e => {
    try {
      data = connect(e).userAgent(userAgent).ignoreHttpErrors(true).ignoreContentType(true).timeout(1).get();
      result.has++;
      result.url.push(e);
    } catch (f) {
      let fM = f.message;
      if (fM.includes("Timeout") || fM.includes("SSL") || fM.includes("ssl")) {
        result.has++;
        result.url.push(e);
      } else {
        // http:// GET 도 SocketTimeout 뜸
      }
    };
  });
  for (var urlLink = 0; urlLink < result.url.length; urlLink++) {
    try {
      result.html.push(connect(result.url[urlLink]).userAgent(userAgent).ignoreHttpErrors(true).ignoreContentType(true).timeout(1200).get());
      
      result.url[urlLink] = result.url[urlLink].replace("https://","");
      
    } catch (e) {
      result.url[urlLink] = result.url[urlLink].replace("https://", "http://");
      result.html.push(connect(result.url[urlLink]).userAgent(userAgent).ignoreHttpErrors(true).ignoreContentType(true).timeout(2000).get());
      
      result.url[urlLink] = result.url[urlLink].replace("http://","");
    }
  }
  return result;
};

module.exports = function (msg) {
  let str = msg.split(" ");

  return str.map(convertString)
}
