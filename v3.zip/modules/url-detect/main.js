const plus = require("./plus");

module.exports = function (msg) {
    var data = plus(msg);
    // ?   data.forEach?
    //plus.js에 모듈함수를 보고 오셈 리턴이 array임 띄어쓰기로 split 했자늠   ?     ㄱㄷ
    let result = [];
    for(var i=0; i<data.length; i++) {
      result.push("url : "+data[i].url+"\n\n사이트 : "+data[i].html[0].select("title").text());
    }
    return result.join("\n\n\n");
};

// 이건 버려진그아?
