let list = [
"\n",
  "\\",
  "!",
  "|",
  ":",
  "$",
  "<",
  ">",
  "[",
  "]",
  "#",
  "$",
  "^",
  "&",
  "*",
  "(",
  ")",
  "'",
  '"',
  ";",
  ",",
  "`",
  "~",
  "{",
  "}"
];

list.push(" ");

function split(content) {
  for(var i = 0; i < list.length; i++) {
    content = content.split(list[i]);
    if(list[i+1]) content = content.join(list[i+1]);
  }
  return content.filter(e => e.includes("."));
}

module.exports = {
  list: list,
  split: split
};
