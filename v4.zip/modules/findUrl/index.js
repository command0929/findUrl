const { request } = require("./request");
const utils = require("./utils");

function findUrl(msg) {

  let content = utils.split(msg);
  
  content = content.map(function (e) {
    if(e.startsWith("https://") || e.startsWith("http://")) return e;
    e = e.split("//");
    if(1 < e.length) return "https://" + e[1];
    return "https://" + e[0];
  });
  
  content = content.map(function (f) {
    let data = request(f);
    if(!data.success) {
      data = request(f.replace("https://", "http://"));
    }
    return data;
  }).filter(g => g.success);
  return content;
}

module.exports = findUrl;
