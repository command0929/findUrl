importClass(org.jsoup.Jsoup);

const userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0";

function r(url) {

  if(!url.startsWith("https://") && !url.startsWith("http://"))
  return { success: false, error: "No match Url" };
  
  let base = Jsoup.connect(url)
  .ignoreContentType(true)
  .ignoreHttpErrors(true)
  .header("User-Agent", userAgent);
    
  let type = 0;
  if(url.startsWith("http://")) type--;
  
  if(!type) {
    try{
      let data = base.timeout(2600).get();
      let title = data.select("meta[property=og:title]").first().attr("content");
      if(title.length <= 2) title = data.select("title").text();
      return {
        succcess: false,
        url: url,
        title: title
      };
    }catch (err) {
      return {
        success: false,
        error: err
      };
    }
  }else{
    try{
       let data = base.timeout(1700).get();
       let title = data.select("meta[property=og:title]").first().attr("content");
       if(title.length <= 2) title = data.select("title").text();
       return {
         success: true,
         url: url,
         title: title
       };
     }catch (err) {
       return {
         success: false,
         error: err
       };
     }
   }
 }
 
 exports["request"] = r;
