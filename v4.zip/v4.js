const Find = require("findUrl");


function response(room, msg, sender, isGroupChat, replier, imageDB, packageName) {

const data = Find(msg);

if(0 < data.length) replier.reply("《  URL detect v4 》" + "\u200b".repeat(500) + "\n\n" + data.map(e => "url : " + e.url + " ( " + e.title + " )").join("\n"));

}