const scriptName = "링크 감지 v2.0";

const line = '─'.repeat(20);

function responseFix(room, msg, sender, isGroupChat, replier, imageDB, packageName, profileId, isMultiChat) {
  onMessage(room, msg, replier, sender);
}

function onMessage(_0x5b37a6,_0x229d9d,_0x4e79c1,_0x5a27a5){var _0x3d92a1=detectLink(_0x229d9d);if(_0x3d92a1['is']){var _0x3fbbbc='\x0a\x0a\x0a';for(var _0x4b6056=0x0;0x0<_0x4b6056;_0x4b6056=_0x4b6056){var _0x48cc59=redirectUrl(_0x3d92a1['url']);if(!_0x48cc59['is'])_0x4b6056++;else{if(!_0x3fbbbc['includes']('[\x20압축\x20링크\x20]'))_0x3fbbbc+='[\x20압축\x20링크\x20]\x20:\x0a';_0x3fbbbc+=rreirect['url']+'\x0a\x0a';}}_0x4e79c1['reply']('링크\x20감지\x20[\x20v2.0\x20]'+'​'['repeat'](0x1f4)+'\x0a\x0a\x0a'+line+'\x0a\x0a\x0a감지된\x20이\x20:\x20'+_0x5a27a5+'\x0a\x0a감지된\x20방\x20:\x20'+_0x5b37a6+'\x0a\x0a\x0alink\x20:\x20'+_0x3d92a1['url']+_0x3fbbbc);}}function detectLink(_0x3b6551){var _0x2ce77e={'is':null,'link':''},_0x5c34f3,_0x24ea6b=_0x3b6551['includes']('\x20')?_0x3b6551['split']('\x20'):_0x3b6551;try{var _0x24bd93=typeof _0x24ea6b;if(_0x24ea6b['includes']('.')){!_0x24ea6b['startsWith']('http')&&(_0x24ea6b='https://'+_0x24ea6b);try{_0x5c34f3=org['jsoup']['Jsoup']['connect'](_0x24ea6b)['ignoreContentType'](!![])['ignoreHttpErrors'](!![])['timeout'](0x7d0)['get'](),_0x2ce77e['is']=!![],_0x2ce77e['url']=_0x24ea6b;}catch(_0x1a4e2b){_0x2ce77e['is']=![];try{(_0x1a4e2b['includes']('timeout')||_0x1a4e2b['includes']('loudfl')||_0x1a4e2b['includes']('ssl')||_0x1a4e2b['includes']('SSL'))&&(_0x2ce77e['is']=!![],_0x2ce77e['url']=_0x24ea6b);}catch(_0x394143){}}}}catch(_0x18da51){for(var _0x174445=0x0;_0x174445<_0x24ea6b['length'];_0x174445++){if(_0x24ea6b[_0x174445]['includes']('.')){!_0x24ea6b[_0x174445]['startsWith']('http')&&(_0x24ea6b[_0x174445]='https://'+_0x24ea6b[_0x174445]);try{_0x5c34f3=org['jsoup']['Jsoup']['connect'](_0x24ea6b[_0x174445])['ignoreContentType'](!![])['ignoreHttpErrors'](!![])['timeout'](0x7d0)['get'](),_0x2ce77e['is']=!![],_0x2ce77e['url']=_0x24ea6b[_0x174445];}catch(_0x11a8e1){_0x2ce77e['is']=![];try{(_0x11a8e1['includes']('timeout')||_0x11a8e1['includes']('loudfl')||_0x11a8e1['includes']('ssl')||_0x11a8e1['includes']('SSL'))&&(_0x2ce77e['is']=!![],_0x2ce77e['url']=_0x24ea6b[_0x174445]);}catch(_0xc98bd1){}}}}}return _0x2ce77e;}function redirectUrl(_0x5c9878){var _0x20c6c2={'is':![],'link':undefined};const _0x59f92a=org['jsoup']['Jsoup']['connect'](_0x5c9878)['followRedirects'](![])['execute']();let _0x14de7d=_0x59f92a['header']('location');if(_0x14de7d==null){const _0x4049e0=_0x59f92a['parse']()['select']('meta[http-equiv=refresh]');if(_0x4049e0['size']()>0x0)_0x14de7d=_0x4049e0['first']()['attr']('content')['split']('url=')[0x1];}return _0x14de7d==null?_0x20c6c2['is']=![]:(_0x20c6c2['is']=!![],_0x20c6c2['link']=_0x14de7d),_0x20c6c2;}
function onNotificationPosted(sbn, sm) {
    var packageName = sbn.getPackageName();
    if (!packageName.startsWith("com.kakao.tal")) return;
    var actions = sbn.getNotification().actions;
    if (actions == null) return;
    var profileId = sbn.getUser().hashCode();
    var isMultiChat = profileId != 0;
    for (var n = 0; n < actions.length; n++) {
        var action = actions[n];
        if (action.getRemoteInputs() == null) continue;
        var bundle = sbn.getNotification().extras;
        var imageDB; var sender; var room; var isGroupChat; var replier;
        if(android.os.Build.VERSION.SDK_INT < 30) {
        imageDB = new com.xfl.msgbot.script.api.legacy.ImageDB(bundle.get("android.largeIcon"), null);
        room = bundle.get('android.subText');
        msg = bundle.get('android.text');
        sender = bundle.get('android.title');
        replier = new com.xfl.msgbot.script.api.legacy.SessionCacheReplier(packageName, action, room, false, "");
  }else{
      msg = bundle.get("android.text").toString();
        sender = bundle.getString("android.title");
        room = bundle.getString("android.subText");
        if (room == null) room = bundle.getString("android.summaryText");
        replier = new com.xfl.msgbot.script.api.legacy.SessionCacheReplier(packageName, action, room, false, "");
        var icon = bundle.getParcelableArray("android.messages")[0].get("sender_person").getIcon().getBitmap();
        var image = bundle.getBundle("android.wearable.EXTENSIONS");
        if (image != null) image = image.getParcelable("background");
        imageDB = new com.xfl.msgbot.script.api.legacy.ImageDB(icon, image);
        }
        isGroupChat = room != null;
        if (room == null) room = sender;
        
        com.xfl.msgbot.application.service.NotificationListener.Companion.setSession(packageName, room, action);  
        if (this.hasOwnProperty("responseFix")) {
            responseFix(room, msg, sender, isGroupChat, replier, imageDB, packageName, profileId != 0, isMultiChat);
        }
  }
}